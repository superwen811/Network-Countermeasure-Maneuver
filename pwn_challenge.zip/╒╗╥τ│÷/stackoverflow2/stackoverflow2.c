#include<string.h>
#include<stdlib.h>
#include<stdio.h>
void init_data()
{
	setvbuf(stdout,0,2,0);
	setvbuf(stdin,0,2,0);
	setvbuf(stderr,0,2,0);	
}
void vul()
{
	char v1[100];
	int v2=0;
	puts("input:");
	gets(v1);
	if(v2==0x12345678)
		system("/bin/sh");
	puts("OK,Bye!");
}
int main()
{
	init_data();
	vul();
	
}
