#include<stdio.h>
#include<string.h>
char bin_sh_str[10] = "/bin/sh";
void init_data()
{
	setvbuf(stdin,0,2,0);
	setvbuf(stdout,0,2,0);
	setvbuf(stderr,0,2,0);
		
}
int main()
{
	init_data();
	vul();
}
void vul()
{
	char s[100];
	puts("what is a syscall?");
	gets(s);
	puts("Bye!");
	
}
void backdoor()
{
	__asm__(
	"movl $0,%eax\n"
	"push %eax\n"
	"pop %ebp\n"
	"pop %eax\n"
	"ret\n"
	);
	__asm__(
	"movl $0,%ebx\n"
	"push %ebx\n"
	"pop %ebx\n"
	"ret\n"	
	);
	__asm__(
	"movl $0,%edx\n"
	"push %edx\n"
	"pop %edx\n"
	"ret\n"
	);
	__asm__(
	"movl $0,%ecx\n"
	"push %ecx\n"
	"pop %ecx\n"
	"ret\n"
	"int $0x80\n"
	);
}
