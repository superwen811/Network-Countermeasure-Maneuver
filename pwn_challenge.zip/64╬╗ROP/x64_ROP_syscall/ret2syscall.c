#include<stdio.h>
#include<string.h>
char bin_sh_str[10] = "/bin/sh";
void init_data()
{
	setvbuf(stdin,0,2,0);
	setvbuf(stdout,0,2,0);
	setvbuf(stderr,0,2,0);
		
}
int main()
{
	init_data();
	vul();
}
void vul()
{
	char s[100];
	puts("what is a syscall?");
	gets(s);
	puts("Bye!");
	
}
void backdoor()
{
	__asm__(
	"movl $0,%eax\n"
	"push %rax\n"
	"pop %rbp\n"
	"pop %rax\n"
	"ret\n"
	);
	__asm__(
	"movq $0,%rdi\n"
	"push %rdi\n"
	"pop %rdi\n"
	"ret\n"	
	);
	__asm__(
	"movq $0,%rsi\n"
	"push %rsi\n"
	"pop %rsi\n"
	"ret\n"
	);
	__asm__(
	"movq $0,%rdx\n"
	"push %rdx\n"
	"pop %rdx\n"
	"ret\n"
	"syscall\n"
	);
}
