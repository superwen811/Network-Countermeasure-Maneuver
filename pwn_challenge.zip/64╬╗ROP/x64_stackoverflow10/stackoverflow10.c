#include<stdio.h>
init_data()
{
	setvbuf(stdin,0,2,0);
	setvbuf(stdout,0,2,0);
	setvbuf(stderr,0,2,0);
}
void vul()
{
	char buf[100];
	printf("input:\n");
	read(0,buf,128);
}
int main()
{
	init_data();
	printf("give your a gift:%p\n",&printf);
	vul();
}
