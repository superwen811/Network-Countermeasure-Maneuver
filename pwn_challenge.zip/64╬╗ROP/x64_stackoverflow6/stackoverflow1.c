#include<string.h>
#include<stdlib.h>
#include<stdio.h>
void init_data()
{
	setvbuf(stdout,0,2,0);
	setvbuf(stdin,0,2,0);
	setvbuf(stderr,0,2,0);	
}
void vul()
{
	char s[100];
	puts("input:");
	gets(s);
	puts("OK,Bye!");
}
int main()
{
	init_data();
	vul();

	
}
void getshell()
{
	system("/bin/sh");
}
