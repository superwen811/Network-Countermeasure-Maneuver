#include <stdio.h>
#include <unistd.h>

char buf[1024];

int main()
{
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
	printf("input your shellcode\n");
    read(0, buf, 1023);
    (*(void (*)()) buf)();
}
