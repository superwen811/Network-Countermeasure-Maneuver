#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int printf(const char* format, ...);

int global_init_var = 84; //已初始化的全局变量
int global_uninit_var;    //未初始化的全局变量
char *str1 = "hello world!"; //字符串常量

void func1(int i)
{
  printf("%d\n", i);
}

int main(void)
{
  static int static_var = 85; //已初始化的静态局部变量
  static int static_var2;     //未初始化的静态局部变量
  char *str2 = "22222";       //字符串常量

  int a = 1;
  int b;
  puts("Hi");
  func1(static_var+static_var2+a+b);

  return a;
}
