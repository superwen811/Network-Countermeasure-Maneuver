# 学校：武汉大学
# 编写者：cjl
# 时间：2023/5/16:9:46
# 定义base64字符集
base64_charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

def base64_encode(input_str):
    # 将输入字符串转为二进制格式
    input_bytes = input_str.encode('utf-8')
    # 计算需要填充的字节数
    padding = 3 - (len(input_bytes) % 3)
    # 在末尾填充0
    input_bytes += b'\x00' * padding
    # 将每三个字节转为四个base64字符
    output_str = ''
    for i in range(0, len(input_bytes), 3):
        # 取出三个字节
        block = int.from_bytes(input_bytes[i:i+3], byteorder='big')
        # 将三个字节转为四个base64字符
        for j in range(4):
            # 取出六位二进制数
            six_bits = (block >> (18 - j * 6)) & 0x3f
            # 将六位二进制数转为base64字符
            output_str += base64_charset[six_bits]
    # 根据填充字节数在末尾添加'='
    output_str = output_str[:-padding] + '=' * padding
    return output_str
print(base64_encode("base64test"))