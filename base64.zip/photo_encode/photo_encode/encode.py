# 学校：武汉大学
# 编写者：cjl
# 时间：2023/5/16:11:04
from PIL import Image
import re
x=400
y=400
f = open("flag.txt",'r')
p  = []
for i in f:
    point  = re.findall("(.*) (.*)",i)[0]
    p.append((int(point[0]),int(point[1])))


pic = Image.open('test.jpg')
img = Image.new('RGB',(400,400),(0,0,0))
for i in range(0,x):
    for j in range(0,y):
        lastrgb = pic.getpixel((i,j))
        img.putpixel((i,j),lastrgb)
        if (i,j) in p:
            rgb = pic.getpixel((i,j))
            rgb=(rgb[0],rgb[1],rgb[2]-5)
            img.putpixel((i,j),rgb)
        print((i,j))
img.save('1.png')
