# 学校：武汉大学
# 编写者：cjl
# 时间：2023/5/16:10:48
from PIL import Image
pic = Image.open('erweima.png')
width,height = pic.size
for i in range(0,width):
    for j in range(0,height):
        rgb=pic.getpixel((i, j))
        if(rgb[0]==255):
            print("%s %s"%(i,j))

