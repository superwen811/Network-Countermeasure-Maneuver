#coding=utf-8
import os
import json
import time
from alive_progress import alive_it
from collections import Counter
try:    
    # 优先使用C语言编译的API xml.etree.cElementTree,响应速度更快   
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

# AI import
import numpy as np
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def resolv_xml(file):
    # target 格式,{"file_name":"xxx","file_uid":xxx,"actions":[x,x,x,x]}
    target = {}
    # 加载xml文件
    tree = ET.parse(file)    
    # 根节点
    root = tree.getroot()
    target["file_name"] =   root.find("file_list").get("file_name")
    target["file_uid"]  = root.find("file_list").get("file_uid")
    target["actions"] = []
    # action_list
    action_list = root.find("file_list").find("file").find("start_boot").find("action_list")   
    # 遍历action
    for action in action_list.findall("action"):
        api_np = {}
        if not action:
            continue
        # apiArg_list
        apiArg_list = action.find("apiArg_list")
        apiArg_np=[]
        if apiArg_list:
            # 遍历apiArg
            apiArgs = apiArg_list.findall("apiArg")
            if apiArgs:
                for apiArg in apiArgs:
                    apiArg_np.append(apiArg.get("value"))
        
        # exInfo_list
        exInfo_list = action.find("exInfo_list")
        exInfo_np = []
        if exInfo_list:
            # 遍历exInfo
            exInfos = exInfo_list.findall("exInfo")
            if exInfos:
                for exInfo in exInfos:
                    exInfo_np.append(exInfo.get("value"))
        # api的属性
        api_np["api_name"]  = action.get("api_name")
        api_np["call_name"] = action.get("call_name")
        api_np["call_pid"]  = action.get("call_pid")
        api_np["call_time"] = action.get("call_time")
        api_np["ret_value"] = action.get("ret_value")
        api_np["apiArgs"] = apiArg_np
        api_np["exInfos"] = exInfo_np
        # 将api的属性加入target
        target["actions"].append(api_np)
    return target


def xml2json(src, dst):
    files = os.listdir(src)
    if not os.path.exists(dst):
        os.mkdir(dst)
    if len(files) == len(os.listdir(dst)):
        return False
    for file in alive_it(files, title="xml2json",spinner = 'pulse'):
        # file:123j1l2k3jk123.xml
        if not file.endswith(".xml"):
            continue
        file_id = os.path.splitext(file)[0] # 123j1l2k3jk123
        xml_addr = os.path.join(src,file)
        json_addr = os.path.join(dst,file_id+".json")
        if  not os.path.exists(json_addr):
            target = resolv_xml(xml_addr)
            with open(json_addr, 'w') as f:
                f.write(json.dumps(target))


def feature_action_diff_attr(src, dst, attr):
    # 对api_name统计并去重
    if os.path.exists(dst):
        return False
    feature_list = {}
    files = os.listdir(src)
    for file in alive_it(files, title="{}".format(dst),spinner = 'pulse'):
        if not file.endswith(".json"): # 检测后缀
            continue
        file_id = os.path.splitext(file)[0]
        json_addr = os.path.join(src,file)
        with open(json_addr,"r") as f:      
            xml_json = json.loads(f.read())
        diff_attr_value = {}
        for action in xml_json['actions']:
            attr_value = action[attr]
            diff_attr_value[attr_value] = 1
        feature_list[file_id] = len(diff_attr_value)
    with open(dst, 'w') as f:
        f.write(json.dumps(feature_list))

def feature_action_special_attr_sum(src, dst, attr, spc_value):
    # 对api_name统计并去重
    if os.path.exists(dst):
        return False
    feature_list = {}
    files = os.listdir(src)
    for file in alive_it(files, title="{}".format(dst),spinner = 'pulse'):
        if not file.endswith(".json"): # 检测后缀
            continue
        file_id = os.path.splitext(file)[0]
        json_addr = os.path.join(src,file)
        with open(json_addr,"r") as f:      
            xml_json = json.loads(f.read())
        special_attr_value = 0
        for action in xml_json['actions']:
            attr_value = action[attr]
            if attr_value == spc_value:
                special_attr_value += 1
        feature_list[file_id] = special_attr_value
    with open(dst, 'w') as f:
        f.write(json.dumps(feature_list))

def feature_action_special_attr_max(src, dst, attr):
    # 对api_name统计并去重
    if os.path.exists(dst):
        return False
    feature_list = {}
    files = os.listdir(src)
    for file in alive_it(files, title="{}".format(dst),spinner = 'pulse'):
        if not file.endswith(".json"): # 检测后缀
            continue
        file_id = os.path.splitext(file)[0]
        json_addr = os.path.join(src,file)
        with open(json_addr,"r") as f:      
            xml_json = json.loads(f.read())
        attr_list = []
        for action in xml_json['actions']:
            attr_value = action[attr]
            attr_list.append(attr_value)
        max_attr_counter = Counter(attr_list).most_common(3)
        max_attr_list = [int(i[0]) for i in max_attr_counter]
        max_attr_list += [0 for i in range(3-len(max_attr_list))]
        feature_list[file_id] = max_attr_list
    with open(dst, 'w') as f:
        f.write(json.dumps(feature_list))



def load_combine_json(category,dst):
    # if os.path.exists(dst):
    #     return False
    action_special_attr_ret_value_0 = "./feature/{}_action_special_attr_ret_value_0.json".format(category)
    action_count_diff_api_name = "./feature/{}_action_count_diff_api_name.json".format(category)
    action_count_diff_call_name = "./feature/{}_action_count_diff_call_name.json".format(category)
    action_count_max_call_pid = "./feature/{}_action_count_max_call_pid.json".format(category)
    json_file_list = [action_special_attr_ret_value_0,action_count_diff_api_name,
                      action_count_diff_call_name,action_count_max_call_pid]
    data = {}
    for file in alive_it(json_file_list, title="combine_json_{}".format(category),spinner = 'pulse'):
        with open(file,"r") as f:      
            feature_json = json.loads(f.read())
            for id in feature_json:
                if id not in data:
                    data[id] = []
                # 根据feature_json[id]的类型来选择合并方式
                if type(feature_json[id]) == int:
                    data[id].append(feature_json[id])
                elif type(feature_json[id]) == list:
                    data[id] += feature_json[id]
    with open(dst, 'w') as f:
        f.write(json.dumps(data))


def resolve(category):
    # 根据方向进行解析
    xml2json("./xml/{}".format(category),"./json/{}".format(category))
    feature_action_special_attr_sum("./json/{}".format(category),"./feature/{}_action_special_attr_ret_value_0.json".format(category),"ret_value","0")
    feature_action_diff_attr("./json/{}".format(category),"./feature/{}_action_count_diff_api_name.json".format(category),"api_name")
    feature_action_diff_attr("./json/{}".format(category),"./feature/{}_action_count_diff_call_name.json".format(category),"call_name")
    feature_action_special_attr_max("./json/{}".format(category),"./feature/{}_action_count_max_call_pid.json".format(category),"call_pid")
    load_combine_json(category,"./data/{}_feature_list.json".format(category))

def main():
    if not os.path.exists("./feature"):
        os.mkdir("./feature")
    if not os.path.exists("./json"):
        os.mkdir("./json")
    if not os.path.exists("./data"):
        os.mkdir("./data")
    resolve("malicious")
    resolve("normal")

def predict(clf,x_predict):
    clf = RandomForestClassifier(criterion="gini",min_samples_leaf=10,min_samples_split=10)
    # x_predict需要对unknown进行数据清洗,特征分析,数据整合提取
    y_predict = clf.predict(x_predict)

def plot_2d(x,y):
    # 对应的X,Y_1,Y_2需要补充对应代码
    X = [1,2,3,4,5,6]
    Y_1 = [3,4,2,3,7,8]
    Y_2 = [1,3,4,7,1,9]
    fig = plt
    fig.plot(X,Y_1,color='g',label='DecisionTreeClassifier')
    fig.plot(X,Y_2,color='b',label='RandomForestClassifier')
    fig.legend(loc=2)
    # fig.show()
    fig.savefig("./plot/plot_2d.png")

def plot_3d(x,y,max_depth):
    # 对应的X,Y,Z需要补充对应代码
    X = [1,2,3,4,5,6]
    Y = [3,4,2,3,7,8]
    Z = [1,3,4,7,1,9]
    fig = plt.figure()
    ax=Axes3D(fig)
    fig.add_axes(ax)
    ax.scatter(X,Y,Z)
    ax.set_xlabel('max_leaf_nodes', fontdict={'size': 15, 'color': 'red'})
    ax.set_ylabel('max_samples', fontdict={'size': 15, 'color': 'red'})
    ax.set_zlabel('cross_score', fontdict={'size': 15, 'color': 'red'})
    # fig.show()
    fig.savefig("./plot/plot_3d.png")

def auto_grid(x,y):
    parameters = {'max_depth':list(range(1,400,1))}
    dtc = RandomForestClassifier()
    clf = RandomizedSearchCV(dtc, parameters, n_iter = 200,n_jobs =4,verbose=3,cv=5)
    clf = clf.fit(x, y)
    parameters = clf.best_params_
    
    new_parameters = {} # 补充best_params_扩大范围的代码
    clf = GridSearchCV(dtc, new_parameters, n_jobs =4,cv=5,verbose=3)
    clf = clf.fit(x, y)
    return clf.best_params_

def plot_pie(x,y,best_params):
    clf = RandomForestClassifier(**best_params)
    # print(cross_val_score(clf, x, y, cv=5).mean())
    clf = clf.fit(x, y)
    data = clf.feature_importances_
    fig = plt
    labels = ["feature1","feature2","feature3"]
    fig.pie(data,labels=labels,autopct='%1.1f%%',startangle=90)
    fig.show()
    return clf

def train(x,y):
    # 对加载x和y,进行训练,并打印5折交叉验证平均值
    dtc = tree.DecisionTreeClassifier(criterion="gini",min_samples_leaf=10,min_samples_split=10)
    rfc = RandomForestClassifier(criterion="gini",min_samples_leaf=10,min_samples_split=10)
    print(cross_val_score(dtc, x, y, cv=5).mean())
    print(cross_val_score(rfc, x, y, cv=5).mean())
    clf = rfc.fit(x, y)
    return clf

if __name__ == "__main__":
    main()
    # x,y = pre_train_data()
    # max_depth = plot_2d(x,y)
    # plot_3d(x,y,max_depth)
    # best_params = auto_grid(x,y)
    # clf,max_score = plot_pie(x,y,best_params)
    # predict(clf,x_predict) # x_predit的获取需要额外补充,具体方法不做约束
