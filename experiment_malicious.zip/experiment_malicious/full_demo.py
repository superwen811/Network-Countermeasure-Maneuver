#coding=utf-8
import os
import json
import time
from alive_progress import alive_it
from collections import Counter
try:    
    # 优先使用C语言编译的API xml.etree.cElementTree,响应速度更快   
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

# AI import
import numpy as np
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def resolv_xml(file):
    # target 格式,{"file_name":"xxx","file_uid":xxx,"actions":[x,x,x,x]}
    target = {}
    # 加载xml文件
    tree = ET.parse(file)    
    # 根节点
    root = tree.getroot()
    target["file_name"] =   root.find("file_list").get("file_name")
    target["file_uid"]  = root.find("file_list").get("file_uid")
    target["actions"] = []
    # action_list
    action_list = root.find("file_list").find("file").find("start_boot").find("action_list")   
    # 遍历action
    for action in action_list.findall("action"):
        api_np = {}
        if not action:
            continue
        # apiArg_list
        apiArg_list = action.find("apiArg_list")
        apiArg_np=[]
        if apiArg_list:
            # 遍历apiArg
            apiArgs = apiArg_list.findall("apiArg")
            if apiArgs:
                for apiArg in apiArgs:
                    apiArg_np.append(apiArg.get("value"))
        
        # exInfo_list
        exInfo_list = action.find("exInfo_list")
        exInfo_np = []
        if exInfo_list:
            # 遍历exInfo
            exInfos = exInfo_list.findall("exInfo")
            if exInfos:
                for exInfo in exInfos:
                    exInfo_np.append(exInfo.get("value"))
        # api的属性
        api_np["api_name"]  = action.get("api_name")
        api_np["call_name"] = action.get("call_name")
        api_np["call_pid"]  = action.get("call_pid")
        api_np["call_time"] = action.get("call_time")
        api_np["ret_value"] = action.get("ret_value")
        api_np["apiArgs"] = apiArg_np
        api_np["exInfos"] = exInfo_np
        # 将api的属性加入target
        target["actions"].append(api_np)
    return target


def xml2json(src, dst):
    files = os.listdir(src)
    if not os.path.exists(dst):
        os.mkdir(dst)
    if len(files) == len(os.listdir(dst)):
        return False
    for file in alive_it(files, title="xml2json",spinner = 'pulse'):
        # file:123j1l2k3jk123.xml
        if not file.endswith(".xml"):
            continue
        file_id = os.path.splitext(file)[0] # 123j1l2k3jk123
        xml_addr = os.path.join(src,file)
        json_addr = os.path.join(dst,file_id+".json")
        if  not os.path.exists(json_addr):
            target = resolv_xml(xml_addr)
            with open(json_addr, 'w') as f:
                f.write(json.dumps(target))


def feature_action_diff_attr(src, dst, attr):
    # 对api_name统计并去重
    if os.path.exists(dst):
        return False
    feature_list = {}
    files = os.listdir(src)
    for file in alive_it(files, title="{}".format(dst),spinner = 'pulse'):
        if not file.endswith(".json"): # 检测后缀
            continue
        file_id = os.path.splitext(file)[0]
        json_addr = os.path.join(src,file)
        with open(json_addr,"r") as f:      
            xml_json = json.loads(f.read())
        diff_attr_value = {}
        for action in xml_json['actions']:
            attr_value = action[attr]
            diff_attr_value[attr_value] = 1
        feature_list[file_id] = len(diff_attr_value)
    with open(dst, 'w') as f:
        f.write(json.dumps(feature_list))

def feature_action_special_attr_sum(src, dst, attr, spc_value):
    # 对api_name统计并去重
    if os.path.exists(dst):
        return False
    feature_list = {}
    files = os.listdir(src)
    for file in alive_it(files, title="{}".format(dst),spinner = 'pulse'):
        if not file.endswith(".json"): # 检测后缀
            continue
        file_id = os.path.splitext(file)[0]
        json_addr = os.path.join(src,file)
        with open(json_addr,"r") as f:      
            xml_json = json.loads(f.read())
        special_attr_value = 0
        for action in xml_json['actions']:
            attr_value = action[attr]
            if attr_value == spc_value:
                special_attr_value += 1
        feature_list[file_id] = special_attr_value
    with open(dst, 'w') as f:
        f.write(json.dumps(feature_list))

def feature_action_special_attr_max(src, dst, attr):
    # 对api_name统计并去重
    if os.path.exists(dst):
        return False
    feature_list = {}
    files = os.listdir(src)
    for file in alive_it(files, title="{}".format(dst),spinner = 'pulse'):
        if not file.endswith(".json"): # 检测后缀
            continue
        file_id = os.path.splitext(file)[0]
        json_addr = os.path.join(src,file)
        with open(json_addr,"r") as f:      
            xml_json = json.loads(f.read())
        attr_list = []
        for action in xml_json['actions']:
            attr_value = action[attr]
            attr_list.append(attr_value)
        max_attr_counter = Counter(attr_list).most_common(3)
        max_attr_list = [int(i[0]) for i in max_attr_counter]
        max_attr_list += [0 for i in range(3-len(max_attr_list))]
        feature_list[file_id] = max_attr_list
    with open(dst, 'w') as f:
        f.write(json.dumps(feature_list))



def load_combine_json(category,dst):
    # if os.path.exists(dst):
    #     return False
    action_special_attr_ret_value_0 = "./feature/{}_action_special_attr_ret_value_0.json".format(category)
    action_count_diff_api_name = "./feature/{}_action_count_diff_api_name.json".format(category)
    action_count_diff_call_name = "./feature/{}_action_count_diff_call_name.json".format(category)
    json_file_list = [action_special_attr_ret_value_0,action_count_diff_api_name,
                      action_count_diff_call_name]
    data = {}
    for file in alive_it(json_file_list, title="combine_json_{}".format(category),spinner = 'pulse'):
        with open(file,"r") as f:      
            feature_json = json.loads(f.read())
            for id in feature_json:
                if id not in data:
                    data[id] = []
                # 根据feature_json[id]的类型来选择合并方式
                if type(feature_json[id]) == int:
                    data[id].append(feature_json[id])
                elif type(feature_json[id]) == list:
                    data[id] += feature_json[id]
    with open(dst, 'w') as f:
        f.write(json.dumps(data))


def resolve(category):
    # 根据方向进行解析
    xml2json("./xml/{}".format(category),"./json/{}".format(category))
    feature_action_special_attr_sum("./json/{}".format(category),"./feature/{}_action_special_attr_ret_value_0.json".format(category),"ret_value","0")
    feature_action_diff_attr("./json/{}".format(category),"./feature/{}_action_count_diff_api_name.json".format(category),"api_name")
    feature_action_diff_attr("./json/{}".format(category),"./feature/{}_action_count_diff_call_name.json".format(category),"call_name")
    load_combine_json(category,"./data/{}_feature_list.json".format(category))

def main():
    if not os.path.exists("./feature"):
        os.mkdir("./feature")
    if not os.path.exists("./json"):
        os.mkdir("./json")
    if not os.path.exists("./data"):
        os.mkdir("./data")
    if not os.path.exists("./plot"):
        os.mkdir("./plot")
    resolve("malicious")
    resolve("normal")
    resolve("unknown")



def pre_train_data():
    malicious_json_addr = "./data/malicious_feature_list.json"
    normal_json_addr = "./data/normal_feature_list.json"

    with open(malicious_json_addr,"r") as f:      
        malicious_json = json.loads(f.read())
    with open(normal_json_addr,"r") as f:      
        normal_json = json.loads(f.read())

    x = []
    y = []
    for id in malicious_json:
        x.append(malicious_json[id])
        y.append(1)
    for id in normal_json:
        x.append(normal_json[id])
        y.append(0)
    return x,y

def pre_predict_data():
    unknown_json_addr = "./data/unknown_feature_list.json"
    with open(unknown_json_addr,"r") as f:      
        unknown_json = json.loads(f.read())
    x_predict = []
    for id in unknown_json:
        x_predict.append([id]+unknown_json[id])
    return x_predict

def plot_2d(x,y):
    X = []
    Y_1 = []
    Y_2 = []
    score = [0,0]
    for depth in alive_it(range(1,20,1), title="2d_pic",spinner = 'pulse'):
        dtc = tree.DecisionTreeClassifier(max_depth=depth,criterion="gini",min_samples_leaf=10,min_samples_split=10)
        rfc = RandomForestClassifier(max_depth=depth,criterion="gini",min_samples_leaf=10,min_samples_split=10)
        dtc_score = cross_val_score(dtc, x, y, cv=5).mean()
        rfc_score = cross_val_score(rfc, x, y, cv=5).mean()
        X.append(depth)
        Y_1.append(dtc_score)
        Y_2.append(rfc_score)
        if rfc_score > score[0]:
            score[0] = rfc_score
            score[1] = depth
    fig = plt
    fig.xlabel('max_depth')
    fig.ylabel('cross_score')  
    fig.plot(X,Y_1,color='g',label='DecisionTreeClassifier')
    fig.plot(X,Y_2,color='b',label='RandomForestClassifier')
    fig.legend(loc=2)
    # fig.show()
    fig.savefig("./plot/plot_2d.png")
    return score[1]

def plot_3d(x,y,max_depth):
    scores = []
    X = []
    Y = []
    Z = []
    for leaf_nodes in alive_it(range(2,50,5), title="3d_pic",spinner = 'pulse'):
        for samples in range(2,200,40):
            clf = RandomForestClassifier(max_leaf_nodes=leaf_nodes, max_samples=samples,max_depth=max_depth,
                                         criterion="gini",n_estimators=100,min_samples_leaf=1,min_samples_split=2)
            cross_score = cross_val_score(clf, x, y, cv=5).mean()
            X.append(leaf_nodes)
            Y.append(samples)
            Z.append(cross_score)
            scores.append(cross_score)
            if cross_score > scores[0]:
                scores = [leaf_nodes,samples,cross_score]
                print(scores)
    fig = plt.figure()
    ax=Axes3D(fig)
    fig.add_axes(ax)
    ax.scatter(X,Y,Z)
    ax.set_xlabel('max_leaf_nodes')
    ax.set_ylabel('max_samples')
    ax.set_zlabel('cross_score')
    # plt.show()
    fig.savefig("./plot/plot_3d.png")

def auto_grid(x,y):
    scores = [0]
    parameters = {'max_depth':list(range(1,400,1)),'max_leaf_nodes':list(range(1,400,1)),'max_samples':list(range(1,400,1))}
    dtc = RandomForestClassifier()
    clf = RandomizedSearchCV(dtc, parameters, n_iter = 100,n_jobs =4,verbose=3,cv=5)
    clf = clf.fit(x, y)
    # print(clf.cv_results_)
    parameters = clf.best_params_
    print(max(clf.cv_results_["mean_test_score"]))

    for key in parameters:
        if parameters[key] <= 2:
            parameters[key] = 3 # 防止参数小于1
        parameters[key] = range(parameters[key]-2,parameters[key]+2,1)

    clf = GridSearchCV(dtc, parameters, n_jobs =4,cv=5,verbose=3)
    clf = clf.fit(x, y)
    return clf.best_params_

def plot_pie(x,y,best_params):
    clf = RandomForestClassifier(**best_params)
    max_score = cross_val_score(clf, x, y, cv=5).mean()
    clf = clf.fit(x, y)
    data = clf.feature_importances_
    fig = plt
    labels = ["ret_value=0","diff_api_name","diff_call_name"]
    fig.pie(data,labels=labels,autopct='%1.1f%%',startangle=90)
    # fig.show()
    fig.savefig("./plot/plot_pie.png")
    return clf,max_score
    
def predict(clf,x_predict):
    no_id_x_predict = []
    for x in x_predict:
        no_id_x_predict.append(x[1:])
    y_predict = clf.predict(no_id_x_predict)
    result_json = {}
    for i in range(len(y_predict)):
        result_json[x_predict[i][0]] = str(y_predict[i])
    with open("./data/张三_李四.json", 'w') as f:
        f.write(json.dumps(result_json))

if __name__ == "__main__":
    main()
    x,y = pre_train_data()
    max_depth = plot_2d(x,y)
    plot_3d(x,y,max_depth)
    best_params = auto_grid(x,y)
    clf,max_score = plot_pie(x,y,best_params)
    print(max_score)
    x_predict = pre_predict_data()
    predict(clf,x_predict)
    