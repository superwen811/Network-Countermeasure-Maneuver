# coding=utf-8
import os
import json
import time
from alive_progress import alive_it
from collections import Counter
try:
   # 优先使用C语言编译的API xml.etree.cElementTree,响应速度更快
   import xml.etree.cElementTree as ET
except ImportError:
   import xml.etree.ElementTree as ET


# 陈江林
# 时间转换函数 将 时:分:秒.毫秒 形式的数据转为以秒为单位的整数
def time_transfer(time_str):
   time_parts = time_str.split(":")
   temp = time_parts[2].split(".")[0]
   time_parts[2] = temp
   seconds = int(time_parts[0]) * 3600 + \
       int(time_parts[1]) * 60 + int(time_parts[2])
   return seconds

# 李雨航 李欣玥
# 统计ret_value为0以及不为0的个数


def feature_action_ret_value_0_or_not0_sum(src, dst_0, dst_not0):
   if os.path.exists(dst_0) or os.path.exists(dst_0):
       return False
   # 计数结果列表
   value_0_list = {}
   value_not0_list = {}
   files = os.listdir(src)
   for file in alive_it(files, title="{}".format(dst_0), spinner='pulse'):
       value_0_count = 0
       value_not0_count = 0
       if not file.endswith(".json"):  # 检测后缀
           continue
       file_id = os.path.splitext(file)[0]
       json_addr = os.path.join(src, file)
       with open(json_addr, "r") as f:
           xml_json = json.loads(f.read())
       for action in xml_json['actions']:
           attr_value = action['ret_value']
           if attr_value == "0":  # 计数ret_value为0
               value_0_count += 1
           else:
               value_not0_count += 1  # 计数ret_value不为0

       value_0_list[file_id] = value_0_count
       value_not0_list[file_id] = value_not0_count
   with open(dst_0, 'w') as f:
       f.write(json.dumps(value_0_list))
   with open(dst_not0, 'w') as f:
       f.write(json.dumps(value_not0_list))


# 陈江林
# 解析单个xml文件
def resolv_xml(file):
   target = {}
   # 加载xml文件
   tree = ET.parse(file)
   # 根节点
   root = tree.getroot()
   target["file_name"] = root.find("file_list").get("file_name")
   target["actions"] = []
   # action_list
   action_list = root.find("file_list").find(
       "file").find("start_boot").find("action_list")
   # 遍历action
   for action in action_list.findall("action"):
       api_attr_list = {}
       if not action:
           continue
       # apiArg_list
       apiArg_list = action.find("apiArg_list")
       apiArg_np = []
       if apiArg_list:
           # 遍历apiArg
           apiArgs = apiArg_list.findall("apiArg")
           if apiArgs:
               for apiArg in apiArgs:
                   apiArg_np.append(apiArg.get("value"))
       # exInfo_list
       exInfo_list = action.find("exInfo_list")
       exInfo_np = []
       if exInfo_list:
           # 遍历exInfo
           exInfos = exInfo_list.findall("exInfo")
           if exInfos:
               for exInfo in exInfos:
                   exInfo_np.append(exInfo.get("value"))
       # api的属性
       api_attr_list["api_name"] = action.get("api_name")
       api_attr_list["call_name"] = action.get("call_name")
       api_attr_list["call_pid"] = action.get("call_pid")
       api_attr_list["call_time"] = action.get("call_time")
       api_attr_list["ret_value"] = action.get("ret_value")
       api_attr_list["apiArgs"] = apiArg_np
       api_attr_list["exInfos"] = exInfo_np
       # 将api的属性加入target
       target["actions"].append(api_attr_list)

   return target

# 将xml文件转换为json格式文件


def xml2json(src, dst):
   files = os.listdir(src)  # 读取源文件夹下的所有文件
   if not os.path.exists(dst):
       os.mkdir(dst)
   if len(files) == len(os.listdir(dst)):
       return False
   for file in alive_it(files, title="xml2json", spinner='pulse'):   # 遍历源文件夹下的文件并以进度条显示扫描进度
       if not file.endswith(".xml"):   # 跳过不以.xml结尾的文件
           continue

       # 0a3c43b883ec3126b0389c9b298e030ee4949a223e6f03c540d88e82e62d00ef
       file_id = os.path.splitext(file)[0]
       xml_addr = os.path.join(src, file)
       # 为目标.json文件生成一个唯一的id作为文件名并拼接成文件路径
       json_addr = os.path.join(dst, file_id+".json")
       if not os.path.exists(json_addr):
           target = resolv_xml(xml_addr)
           with open(json_addr, 'w') as f:
               f.write(json.dumps(target))  # 解析xml文件写入json文件中

# 何迅
# 统计apiArg的数目、为0的数目、不为0的数目、与action相除的值

def get_apiArg_count(src, dst_arg_count, dst_arg_0, dst_arg_not0, dst_arg_div):

   if os.path.exists(dst_arg_count) or os.path.exists(dst_arg_0) or os.path.exists(dst_arg_not0) or os.path.exists(dst_arg_div):
       return False

   arg_count_list = {}
   arg_0_list = {}
   arg_not0_list = {}
   arg_div_list = {}

   files = os.listdir(src)
   for file in alive_it(files, title="{}".format(dst_arg_count), spinner='pulse'):
       action_count = 0  # actions节的总数量
       apiArg_count = 0  # apiArg的总数量
       apiArg_0_count = 0  # apiArg的value为0的数量
       apiArg_not0_count = 0  # apiArg的value不为0的数量
       # 扫描每个文件之前将它们清空为0
       if not file.endswith(".json"):  # 检测后缀是否为.json
           continue
       file_id = os.path.splitext(file)[0]
       json_addr = os.path.join(src, file)
       with open(json_addr, "r") as f:
           xml_json = json.loads(f.read())  # 读源json文件

       action_count = len(xml_json['actions'])  # action节的数目等于actions字典的长度
       for action in xml_json['actions']:  # 遍历每一个action节
           apiArgs = action['apiArgs']  # 读取action节的apiArgs字典
           # 当前apiArg的数目等于apiArgs字典的长度，将其加入到apiArg总数中
           apiArg_count = apiArg_count + len(apiArgs)
           for apiArg in apiArgs:  # 遍历当前apiArgs字典中的每个apiArg
               if apiArg == "0":
                   apiArg_0_count = apiArg_0_count + 1  # 累加apiArg的value为0的数目
               else:
                   apiArg_not0_count = apiArg_not0_count + 1  # 累加apiArg的value不为0的数目
       if action_count:
           apiArg_div_action = float(apiArg_count) / \
               float(action_count)  # 确保分母不为0的情况下进行浮点数除法
       else:
           apiArg_div_action = 0

       arg_count_list[file_id] = apiArg_count
       arg_0_list[file_id] = apiArg_0_count
       arg_not0_list[file_id] = apiArg_not0_count
       arg_div_list[file_id] = apiArg_div_action

   with open(dst_arg_count, 'w') as f:
       f.write(json.dumps(arg_count_list))
   with open(dst_arg_0, 'w') as f:
       f.write(json.dumps(arg_0_list))
   with open(dst_arg_not0, 'w') as f:
       f.write(json.dumps(arg_not0_list))
   with open(dst_arg_div, 'w') as f:
       f.write(json.dumps(arg_div_list))

# 李雨航、李欣玥、何迅
# 函数功能是：
# 计算exInfo总数量
# 计算exInfo的总数量除以action节的数量
# 计算exInfo value中包含exe的数量
# 计算exInfo value中包含dll的数量


def get_exInfo_count(src, dst_exInfo_count, dst_exInfo_div_action, dst_exInfo_value_exe, dst_exInfo_value_dll):
   if os.path.exists(dst_exInfo_count) or os.path.exists(dst_exInfo_div_action) or os.path.exists(dst_exInfo_value_exe) or os.path.exists(dst_exInfo_value_dll):
       return False
   # 定义四个有关exInfo的数量结果列表
   exInfo_count_list = {}
   exInfo_div_action_list = {}
   exInfo_value_exe_list = {}
   exInfo_value_dll_list = {}

   files = os.listdir(src)
   for file in alive_it(files, title="{}".format(dst_exInfo_count), spinner='pulse'):
       action_count = 0  # actions节的总数量
       exInfo_count = 0  # exInfo的总数量
       exInfo_value_exe_count = 0  # exInfo value中包含exe的数量
       exInfo_value_dll_count = 0  # exInfo value中包含dll的数量
       if not file.endswith(".json"):  # 检测后缀是否为.json
           continue
       file_id = os.path.splitext(file)[0]
       json_addr = os.path.join(src, file)
       with open(json_addr, "r") as f:
           xml_json = json.loads(f.read())  # 读源json文件

       action_count = len(xml_json['actions'])  # action节的数目等于actions字典的长度
       for action in xml_json['actions']:  # 遍历每一个action节
           exInfos = action['exInfos']  # 读取action节的exInfos字典
           # 当前exInfo的数目等于exInfos字典的长度，将其加入到exInfo总数中
           exInfo_count += len(exInfos)
           for exInfo in exInfos:  # 遍历当前exInfos字典中的每个exInfo
               if "exe" in exInfo:
                   exInfo_value_exe_count += 1  # 累加exInfo的value中包含exe的数目
               if "dll" in exInfo:
                   exInfo_value_dll_count += 1  # 累加exInfo的value中包含dll的数目
       if action_count:
           exInfo_div_action_count = float(exInfo_count) / \
               float(action_count)  # 确保分母不为0的情况下进行浮点数除法
       else:
           exInfo_div_action_count = 0

       exInfo_count_list[file_id] = exInfo_count
       exInfo_div_action_list[file_id] = exInfo_div_action_count
       exInfo_value_exe_list[file_id] = exInfo_value_exe_count
       exInfo_value_dll_list[file_id] = exInfo_value_dll_count
   with open(dst_exInfo_count, 'w') as f:
       f.write(json.dumps(exInfo_count_list))
   with open(dst_exInfo_div_action, 'w') as f:
       f.write(json.dumps(exInfo_div_action_list))
   with open(dst_exInfo_value_exe, 'w') as f:
       f.write(json.dumps(exInfo_value_exe_list))
   with open(dst_exInfo_value_dll, 'w') as f:
       f.write(json.dumps(exInfo_value_dll_list))


# 何迅
# 统计action数量

def get_action_count(src, dst):
   # 统计action数量
   if os.path.exists(dst):
       return False
   feature_list = {}
   action_count = 0
   files = os.listdir(src)
   for file in alive_it(files, title="{}".format(dst), spinner='pulse'):
       if not file.endswith(".json"):  # 检测后缀
           continue
       file_id = os.path.splitext(file)[0]
       json_addr = os.path.join(src, file)
       with open(json_addr, "r") as f:
           xml_json = json.loads(f.read())

       for action in xml_json['actions']:
           action_count = action_count + 1
       feature_list[file_id] = action_count
   with open(dst, 'w') as f:
       f.write(json.dumps(feature_list))

# 陈江林
# 求第一个call_time、最后一个call_time及二者差值


def feature_action_call_time(src, dst_first, dst_last, dst_gap):
   # 对action节中的call_time属性进行特征取出，第一个call_time时间，最后一个call_time，以及两者之差，分别写入dst_*
   # 首先判断目标地址是否存在，存在返回错误
   if os.path.exists(dst_first) or os.path.exists(dst_last) or os.path.exists(dst_gap):
       return False
   feature_list = {}
   # 与之前相同，先加载文件，对于后缀不是json的就跳过
   files = os.listdir(src)
   call_time_first = {}
   call_time_last = {}
   call_time_gap = {}
   # 进度条
   for file in alive_it(files, title="{}".format(dst_first), spinner='pulse'):
       if not file.endswith(".json"):  # 检测后缀
           continue
       # 先根据源文件位置定位目标文件位置
       file_id = os.path.splitext(file)[0]
       json_addr = os.path.join(src, file)
       with open(json_addr, "r") as f:
           xml_json = json.loads(f.read())  # 读取源文件内容
       actions = xml_json['actions']
       action_first = actions[0]
       action_last = actions[-1]
       call_time_first[file_id] = time_transfer(action_first["call_time"])
       call_time_last[file_id] = time_transfer(action_last["call_time"])
       call_time_gap[file_id] = time_transfer(
           action_last["call_time"]) - time_transfer(action_first["call_time"])
   with open(dst_first, 'w') as f:
       f.write(json.dumps(call_time_first))
   with open(dst_last, 'w') as f:
       f.write(json.dumps(call_time_last))
   with open(dst_gap, 'w') as f:
       f.write(json.dumps(call_time_gap))

# 对action节中的attr属性的数量进行统计并求得去重数量


def feature_action_diff_attr(src, dst, attr):
   if os.path.exists(dst):
       return False
   feature_list = {}
   files = os.listdir(src)
   for file in alive_it(files, title="{}".format(dst), spinner='pulse'):
       if not file.endswith(".json"):  # 检测后缀
           continue
       file_id = os.path.splitext(file)[0]
       json_addr = os.path.join(src, file)
       with open(json_addr, "r") as f:
           xml_json = json.loads(f.read())
       diff_attr_value = {}
       for action in xml_json['actions']:
           attr_value = action[attr]
           diff_attr_value[attr_value] = 1
       feature_list[file_id] = len(diff_attr_value)
   with open(dst, 'w') as f:
       f.write(json.dumps(feature_list))

# 严书雯
# 对attr属性值进行统计并求出出现次数的最大值


def feature_action_special_attr_max(src, dst, attr):
   if os.path.exists(dst):  # 检测目标文件是否存在
       return False
   feature_list = {}
   files = os.listdir(src)  # 打开文件
   for file in alive_it(files, title="{}".format(dst), spinner='pulse'):
       if not file.endswith(".json"):  # 检测后缀
           continue
       file_id = os.path.splitext(file)[0]  # 取文件名前缀
       json_addr = os.path.join(src, file)  # 拼接成完整文件路径
       with open(json_addr, "r") as f:
           xml_json = json.loads(f.read())  # 读取文件内容
       attr_list = []
       for action in xml_json['actions']:  # 遍历actions字典
           attr_value = action[attr]  # 取attr对应的values
           attr_list.append(attr_value)  # 生成attr属性值列表
       max_attr_counter = Counter(attr_list).most_common(1)  # 统计出现频率最高的一个元组
       max_attr_result = int(max_attr_counter[0][0])  # 取这个元组中的频率，转为int
       feature_list[file_id] = max_attr_result
   with open(dst, 'w') as f:
       f.write(json.dumps(feature_list))

# 严书雯
# 统计attr属性值为spc_value的数量


def feature_action_special_attr_sum(src, dst, attr, spc_value):

   if os.path.exists(dst):
       return False
   feature_list = {}
   files = os.listdir(src)
   for file in alive_it(files, title="{}".format(dst), spinner='pulse'):
       if not file.endswith(".json"):  # 检测后缀
           continue
       file_id = os.path.splitext(file)[0]  # 取文件名前缀
       json_addr = os.path.join(src, file)  # 拼接成完整文件路径
       with open(json_addr, "r") as f:
           xml_json = json.loads(f.read())  # 读取文件内容
       special_attr_value = 0
       for action in xml_json['actions']:  # 遍历actions字典
           attr_value = action[attr]  # 取attr对应的values
           if attr_value == spc_value:  # 键值values等于特征值spc_value
               special_attr_value += 1  # 数量加一
       feature_list[file_id] = special_attr_value
   with open(dst, 'w') as f:
       f.write(json.dumps(feature_list))

# 对所有的特征进行加载组合 生成预训练数据


def load_combine_json(category, dst):
   action_count = "./feature/{}_action_count.json".format(category)
   action_count_diff_api_name = "./feature/{}_action_count_diff_api_name.json".format(category)
   action_diff_call_pid = "./feature/{}_action_count_diff_call_pid.json".format(category)
   action_dff_ret_value = "./feature/{}_action_count_diff_ret_value.json".format(category)
   action_exInfo_count = "./feature/{}_action_exInfo_count.json".format(
       category)
   action_exInfo_div_action = "./feature/{}_action_exInfo_div_action.json".format(
       category)
   action_exInfo_value_exe_count = "./feature/{}_action_exInfo_value_exe_count.json".format(
       category)
   action_exInfo_value_dll_count = "./feature/{}_action_exInfo_value_dll_count.json".format(
       category)
   action_special_attr_ret_value_0 = "./feature/{}_action_special_attr_ret_value_0.json".format(category)
   action_special_attr_ret_value_not_0 = "./feature/{}_action_special_attr_ret_value_not_0.json".format(category)
   action_first_call_time = "./feature/{}_first_call_time.json".format(category)
   action_last_call_time = "./feature/{}_last_call_time.json".format(category)
   action_call_time_gap = "./feature/{}_call_time_gap.json".format(category)
   action_apiArg_count = "./feature/{}_apiArg_count.json".format(category)
   action__apiArg_0_count= "./feature/{}_apiArg_0_count.json".format(category)
   action_apiArg_not0_count = "./feature/{}_apiArg_not0_count.json".format(category)
   action_apiArg_div_action = "./feature/{}_apiArg_div_action.json".format(category)
   action_count_max_call_pid = "./feature/{}_action_count_max_call_pid.json".format(category)
   action_special_attr_call_pid_0 = "./feature/{}_action_special_attr_call_pid_0.json".format(category)
   # json文件字典，表明用哪些特征进行分析
   json_file_dict = {action_count:1, action_count_diff_api_name:1,action_diff_call_pid:1,action_dff_ret_value:1,
                     action_exInfo_count:1,action_exInfo_div_action:1,action_exInfo_value_exe_count:1,
                     action_exInfo_value_dll_count:1,action_special_attr_ret_value_0:1,action_special_attr_ret_value_not_0:1,
                     action_first_call_time:0,action_last_call_time:0,action_call_time_gap:0,
                     action_apiArg_count:1,action__apiArg_0_count:1,action_apiArg_not0_count:1,
                     action_apiArg_div_action:1,action_count_max_call_pid:1,action_special_attr_call_pid_0:1}
   json_file_list =[]
   for key, value in json_file_dict.items():
       if value == 1:
           json_file_list.append(key)
   
   data = {}
   for file in alive_it(json_file_list, title="combine_json_{}".format(category), spinner='pulse'):
       with open(file, "r") as f:
           feature_json = json.loads(f.read())
           for id in feature_json:
               if id not in data:
                   data[id] = []
               # 根据feature_json[id]的类型来选择合并方式
               if type(feature_json[id]) == int:
                   data[id].append(feature_json[id])
               elif type(feature_json[id]) == list:
                   data[id] += feature_json[id]
   with open(dst, 'w') as f:
       f.write(json.dumps(data))

# 根据方向进行解析


def resolve(category):

   '''xml2json("./xml/{}".format(category), "./json/{}".format(category))
   feature_action_diff_attr("./json/{}".format(category),
                            "./feature/{}_action_count_diff_api_name.json".format(category), "api_name")
   feature_action_diff_attr("./json/{}".format(category),
                            "./feature/{}_action_count_diff_call_pid.json".format(category), "call_pid")
   feature_action_diff_attr("./json/{}".format(category),
                            "./feature/{}_action_count_diff_ret_value.json".format(category), "ret_value")
   get_exInfo_count("./json/{}".format(category),
                    "./feature/{}_action_exInfo_count.json".format(category),
                    "./feature/{}_action_exInfo_div_action.json".format(
                        category),
                    "./feature/{}_action_exInfo_value_exe_count.json".format(
                        category),
                    "./feature/{}_action_exInfo_value_dll_count.json".format(category))
   feature_action_ret_value_0_or_not0_sum("./json/{}".format(category),
                                          "./feature/{}_action_special_attr_ret_value_0.json".format(
                                              category),
                                          "./feature/{}_action_special_attr_ret_value_not_0.json".format(category))
   get_action_count("./json/{}".format(category),
                    "./feature/{}_action_count.json".format(category))
   feature_action_call_time("./json/{}".format(category),
                            "./feature/{}_first_call_time.json".format(
                                category),
                            "./feature/{}_last_call_time.json".format(
                                category),
                            "./feature/{}_call_time_gap.json".format(category))
   get_apiArg_count("./json/{}".format(category),
                    "./feature/{}_apiArg_count.json".format(category),
                    "./feature/{}_apiArg_0_count.json".format(category),
                    "./feature/{}_apiArg_not0_count.json".format(category),
                    "./feature/{}_apiArg_div_action.json".format(category))
   feature_action_special_attr_max(
       "./json/{}".format(category), "./feature/{}_action_count_max_call_pid.json".format(category), "call_pid")
   feature_action_special_attr_sum(
       "./json/{}".format(category), "./feature/{}_action_special_attr_call_pid_0.json".format(category), "call_pid", "0")
'''
   load_combine_json(category, "./data/{}_feature_list.json".format(category))


def main():
   if not os.path.exists("./feature"):
       os.mkdir("./feature")
   if not os.path.exists("./json"):
       os.mkdir("./json")
   if not os.path.exists("./data"):
       os.mkdir("./data")
   resolve("malicious")
   resolve("normal")


if __name__ == "__main__":
   main()