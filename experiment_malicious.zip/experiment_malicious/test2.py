import os
import json
import time
from alive_progress import alive_it
from collections import Counter
try:    
    # 优先使用C语言编译的API xml.etree.cElementTree,响应速度更快   
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

# AI import
import numpy as np
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
def unknown_test_data():
    x_predict = []
    file_name_list = []
    unknown_feature_file = "./data/unknown_feature_list.json"
    with open(unknown_feature_file, "r") as f:
        unknown_feature_json = json.loads(f.read())
        for key, value in unknown_feature_json.items():
            file_name_list.append(key)   #取出名字
            x_predict.append(value)
    return x_predict,file_name_list
x_predict,file_name_list=unknown_test_data()
print(len(x_predict))
y_predict = []
for i in range(0,len(x_predict)):
    y_predict.append(i%2)
answer_predict = {}
for i in range(0,len(y_predict),1):
    answer_predict[file_name_list[i]] = y_predict[i]
with open("a.json","w") as f:
    f.write(json.dumps(answer_predict))